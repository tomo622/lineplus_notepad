package com.lineplus.notepad;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MemoActivity extends AppCompatActivity {
    public static final String INTENT_REQ_NEW = "INTENT_REQ_NEW";
    public static final String INTENT_REQ_ITEM = "INTENT_REQ_ITEM";
    private boolean isNew;
    private MemoItem memoItem;

    private ConstraintLayout constLayout_back;
    private ImageView img_back;
    private TextView txt_back;
    private TextView txt_date;
    private EditText edit_title;
    private EditText edit_content;
    private ImageButton imgBnt_deleteMemo;
    private ImageButton imgBtn_addMemo;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memo);

        Intent intent = getIntent();
        if(intent.hasExtra(INTENT_REQ_NEW)) {
            isNew = intent.getBooleanExtra(INTENT_REQ_NEW, false);
        }
        if(isNew){
            memoItem = new MemoItem();
        }
        else{
            if(intent.hasExtra(INTENT_REQ_ITEM)){
                memoItem = (MemoItem) intent.getSerializableExtra(INTENT_REQ_ITEM);
            }
        }

        if(memoItem == null){
            Log.e("MEMO ACTIVITY", "MemoItem object is null.");
            return;
        }

        constLayout_back = findViewById(R.id.memo_constLayout_back);
        img_back = findViewById(R.id.memo_img_back);
        txt_back = findViewById(R.id.memo_txt_back);
        txt_date = findViewById(R.id.memo_txt_date);
        edit_title = findViewById(R.id.memo_edit_title);
        edit_content = findViewById(R.id.memo_edit_content);
        imgBnt_deleteMemo = findViewById(R.id.memo_imgBnt_deleteMemo);
        imgBtn_addMemo = findViewById(R.id.memo_imgBtn_addMemo);


    }
}
