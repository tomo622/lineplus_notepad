package com.lineplus.notepad;

public interface OnCheckMemoItemSelect {
    void checkSelectedCount(int cnt);
}
