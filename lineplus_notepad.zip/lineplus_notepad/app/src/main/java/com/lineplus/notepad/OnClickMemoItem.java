package com.lineplus.notepad;

public interface OnClickMemoItem {
    void onClick(MemoItem memoItem);
}
